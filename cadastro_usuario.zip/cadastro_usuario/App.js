import * as React from 'react';
import { useState } from 'react';
import {
  Text,
  View,
  TextInput,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
  StyleSheet,
  Alert,
  Image,
} from 'react-native';
import AppLoading from 'expo-app-loading';
import {
  useFonts,
  Poppins_400Regular,
  Poppins_600SemiBold,
} from '@expo-google-fonts/poppins';

// Navegação
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

const Stack = createNativeStackNavigator();

// ----------- TELA INICIAL / SPLASH -----------
function SplashScreen({ navigation }) {
  return (
    <SafeAreaView style={styles.splashContainer}>
      <View style={styles.splashContent}>
        <Image
          source={require('./pngwing.com.png')}
          style={{ width: 100, height: 100, marginBottom: 20 }}
        />
        <Text style={styles.splashTitle}>Flower Power</Text>

        <TouchableOpacity
          style={styles.btnPrimary}
          onPress={() => navigation.navigate('Cadastro')}>
          <Text style={styles.btnText}>Começar</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// ----------- TELA DE CADASTRO (card estilizado) -----------
function CadastroScreen({ navigation, pessoas, setPessoas }) {
  const [nome, setNome] = useState('');
  const [email, setEmail] = useState('');

  function salvar() {
    if (!nome.trim() || !email.trim()) {
      Alert.alert('Atenção', 'Preencha nome e email.');
      return;
    }

    const novo = {
      id: Date.now().toString(),
      nome: nome.trim(),
      email: email.trim(),
    };

    setPessoas((prev) => [novo, ...prev]);
    setNome('');
    setEmail('');
    navigation.navigate('Lista');
  }

  return (
    <SafeAreaView style={styles.containerCenter}>
      <View style={styles.card}>
        <Text style={styles.title}>Cadastrar Usuário</Text>

        {/* Campo Nome */}
        <View style={styles.field}>
          <Text style={styles.label}>Nome</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite o nome"
            value={nome}
            onChangeText={setNome}
          />
        </View>

        {/* Campo Email */}
        <View style={styles.field}>
          <Text style={styles.label}>Email</Text>
          <TextInput
            style={styles.input}
            placeholder="Digite o email"
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
          />
        </View>

        <TouchableOpacity style={styles.btnPrimary} onPress={salvar}>
          <Text style={styles.btnText}>Salvar</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.btnSecondary, { marginTop: 12 }]}
          onPress={() => navigation.navigate('Lista')}>
          <Text style={styles.btnText}>Ver Lista</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

// ----------- TELA DE LISTA -----------
function ListaScreen({ pessoas, setPessoas }) {
  function deletar(id) {
    setPessoas((prev) => prev.filter((p) => p.id !== id));
  }

  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.title}>Lista de Cadastros</Text>

      {pessoas.length === 0 ? (
        <Text style={{ textAlign: 'center', marginTop: 16, color: '#555' }}>
          Nenhum cadastro ainda. Vá até "Cadastro" e adicione um novo.
        </Text>
      ) : (
        <FlatList
          data={pessoas}
          keyExtractor={(item) => item.id}
          ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
          renderItem={({ item }) => (
            <View style={styles.item}>
              <Text style={styles.itemText}>🌸 {item.nome}</Text>
              <Text style={styles.itemSub}>📧 {item.email}</Text>

              <TouchableOpacity
                style={styles.btnDelete}
                onPress={() => deletar(item.id)}>
                <Text style={styles.btnDeleteText}>Excluir</Text>
              </TouchableOpacity>
            </View>
          )}
        />
      )}
    </SafeAreaView>
  );
}

// ----------- APP PRINCIPAL -----------
export default function App() {
  const [pessoas, setPessoas] = useState([]);

  let [fontsLoaded] = useFonts({
    Poppins_400Regular,
    Poppins_600SemiBold,
  });

  if (!fontsLoaded) {
    return <AppLoading />;
  }

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Splash">
        <Stack.Screen
          name="Splash"
          component={SplashScreen}
          options={{ headerShown: false }}
        />
        <Stack.Screen name="Cadastro">
          {(props) => (
            <CadastroScreen
              {...props}
              pessoas={pessoas}
              setPessoas={setPessoas}
            />
          )}
        </Stack.Screen>
        <Stack.Screen name="Lista">
          {(props) => (
            <ListaScreen {...props} pessoas={pessoas} setPessoas={setPessoas} />
          )}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}

// ----------- ESTILOS -----------
const styles = StyleSheet.create({
  splashContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e8f5e9',
  },
  splashContent: {
    alignItems: 'center',
  },
  splashTitle: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#2e7d32',
    fontFamily: 'Poppins_600SemiBold',
  },
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f1f8f6',
  },
  containerCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#e8f5e9',
    padding: 20,
  },
  card: {
    backgroundColor: '#e8f5e9',
    padding: 25,
    borderRadius: 20,
    width: '100%',
    maxWidth: 400,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 6,
    elevation: 5,
  },
  title: {
    fontSize: 22,
    marginBottom: 20,
    textAlign: 'center',
    fontWeight: '600',
    color: '#2e7d32',
    fontFamily: 'Poppins_600SemiBold',
  },
  field: {
    width: '100%',
    marginBottom: 16,
  },
  label: {
    fontSize: 16,
    marginBottom: 6,
    color: '#388e3c',
    fontFamily: 'Poppins_400Regular',
  },
  input: {
    borderWidth: 1,
    borderColor: '#a5d6a7',
    borderRadius: 12,
    padding: 12,
    fontSize: 16,
    backgroundColor: '#fff',
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowOffset: { width: 1, height: 2 },
  },
  item: {
    padding: 16,
    backgroundColor: '#c8e6c9',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOpacity: 0.1,
    shadowOffset: { width: 1, height: 2 },
  },
  itemText: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1b5e20',
    fontFamily: 'Poppins_600SemiBold',
  },
  itemSub: {
    fontSize: 14,
    color: '#33691e',
    marginBottom: 8,
    fontFamily: 'Poppins_400Regular',
  },
  btnPrimary: {
    backgroundColor: '#66bb6a',
    padding: 14,
    borderRadius: 25,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: '#000',
    shadowOpacity: 0.15,
    shadowOffset: { width: 2, height: 4 },
  },
  btnSecondary: {
    backgroundColor: '#81c784',
    padding: 14,
    borderRadius: 25,
    alignItems: 'center',
  },
  btnText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 16,
    fontFamily: 'Poppins_600SemiBold',
  },
  btnDelete: {
    backgroundColor: '#ef5350',
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    alignSelf: 'flex-start',
  },
  btnDeleteText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
    fontFamily: 'Poppins_600SemiBold',
  },
});
